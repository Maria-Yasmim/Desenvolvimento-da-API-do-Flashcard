# flashcards-api

## Proósito
Este é um trabalho ensinar os príncipios básicos para a criação de uma API para o Curso Técnico de Informática. Flashcard é um método de estudos conhecido como _Spaced Repeatition System (SRS)_.
